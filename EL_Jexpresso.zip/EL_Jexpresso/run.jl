using ONNXRunTime

# Load ONNX model
sess = ONNXRunTime.load_inference("model.onnx")

# Inspect input/output names (important once)
println("Inputs: ", sess.input_names)
println("Outputs: ", sess.output_names)

# Create a single sample input
# For a FC net, this is typically (batch, features)
input_name = first(sess.input_names)
output_name = first(sess.output_names)

N_in = 169                     # input dimension of your FC network
x = rand(Float32, 1, N_in)    # batch size = 1

# Run inference
y = sess(Dict(input_name => x))

# Extract output
ŷ = y[output_name]

println("Output size = ", size(ŷ))
println(ŷ)
